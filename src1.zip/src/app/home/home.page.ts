import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  constructor() {}
    Apartments: any[] = [
      {
        "name":"Apartment 1",
        "address":"Batangas City",
        "price":"PHP 1,000",
        "image":"https://coolhouseconcepts.com/wp-content/uploads/2021/06/PIC-03-26-678x381.jpg",
      },
      {
        "name":"Apartment 2",
        "address":"Batangas City",
        "price":"PHP 2,000",
        "image":"https://theoldhouselife.com/wp-content/uploads/2018/09/ISu47phnmh4flg1000000000.jpg",
      },
      {
        "name":"Apartment 3",
        "address":"Batangas City",
        "price":"PHP 3,000",
        "image":"https://cdn.vox-cdn.com/thumbor/frFQQhOsxl8DctGjkR8OLHpdKMs=/0x0:3686x2073/1200x800/filters:focal(1549x743:2137x1331)/cdn.vox-cdn.com/uploads/chorus_image/image/68976842/House_Tour_Liverman_3D6A3138_tour.0.jpg",
      },
      {
        "name":"Apartment 4",
        "address":"Batangas City",
        "price":"PHP 4,000",
        "image":"https://thumbor.forbes.com/thumbor/fit-in/900x510/https://www.forbes.com/advisor/wp-content/uploads/2021/08/download-23.jpg",
      },
      {
        "name":"Apartment 5",
        "address":"Batangas City",
        "price":"PHP 5,000",
        "image":"https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/Gelbensande3.jpg/1200px-Gelbensande3.jpg",
      },
    ]
  }
